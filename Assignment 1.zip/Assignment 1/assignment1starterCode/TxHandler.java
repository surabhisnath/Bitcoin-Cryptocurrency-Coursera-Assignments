import java.util.*;


public class TxHandler 
{

    /**
     * Creates a public ledger whose current UTXOPool (collection of unspent transaction outputs) is
     * {@code utxoPool}. This should make a copy of utxoPool by using the UTXOPool(UTXOPool uPool)
     * constructor.
     */

    UTXOPool copy;

    public TxHandler(UTXOPool utxoPool) 
    {
        copy = new UTXOPool(utxoPool);
    }

    /**
     * @return true if:
     * (1) all outputs claimed by {@code tx} are in the current UTXO pool, 
     * (2) the signatures on each input of {@code tx} are valid, 
     * (3) no UTXO is claimed multiple times by {@code tx},
     * (4) all of {@code tx}s output values are non-negative, and
     * (5) the sum of {@code tx}s input values is greater than or equal to the sum of its output
     *     values; and false otherwise.
     */
    public boolean isValidTx(Transaction tx) 
    {
        HashSet t = new HashSet();

        double sumone=0, sumtwo=0;
        

        for(int i=0; i<tx.getInputs().size(); i++)
        {
            Transaction.Input in = tx.getInputs().get(i);
            
            UTXO prev = new UTXO(in.prevTxHash, in.outputIndex);

            Transaction.Output prevtrans = copy.getTxOutput(prev);

            if(copy.contains(prev) == false)
                return false;

            if(in.signature == null)
                return false;

            if(Crypto.verifySignature(prevtrans.address,tx.getRawDataToSign(i),in.signature) == false)
                return false;

            t.add(prev);
            sumone+=prevtrans.value;
        }

        if(t.size() != tx.getInputs().size())
            return false;


        for(int j=0; j<tx.getOutputs().size(); j++)
        {
            Transaction.Output out = tx.getOutputs().get(j);
            if(out.value < 0)
                return false;
            sumtwo+=out.value;
        }

        if(sumone < sumtwo)
            return false;


        return true;
    }

    /**
     * Handles each epoch by receiving an unordered array of proposed transactions, checking each
     * transaction for correctness, returning a mutually valid array of accepted transactions, and
     * updating the current UTXO pool as appropriate.
     */
    public Transaction[] handleTxs(Transaction[] possibleTxs) 
    {
        if(possibleTxs == null)
        {
            return new Transaction[0];
        }

        ArrayList<Transaction> validtrans = new ArrayList<>();

        for (int k=0; k<possibleTxs.length; k++) 
        {

            Transaction trans = possibleTxs[k];

            if (isValidTx(trans) == false) 
            {
                continue;
            }

            validtrans.add(trans);

            for (int m=0; m<trans.getInputs().size(); m++) 
            {

                Transaction.Input input = trans.getInputs().get(m);    
                UTXO utxo = new UTXO(input.prevTxHash, input.outputIndex);
                copy.removeUTXO(utxo);
            }

            byte[] transHash = trans.getHash();
            
            int index = 0;
            
            for (int n=0; n<trans.getOutputs().size(); n++) 
            {
                Transaction.Output output = trans.getOutputs().get(n);
                UTXO utxo = new UTXO(transHash, index);
                index++;
                copy.addUTXO(utxo, output);
            }
        }

        return validtrans.toArray(new Transaction[validtrans.size()]);

    }

}

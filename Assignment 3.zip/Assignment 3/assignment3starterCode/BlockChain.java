// Block Chain should maintain only limited block nodes to satisfy the functions
// You should not have all the blocks added to the block chain in memory 
// as it would cause a memory overflow.

import java.util.*;


class Node
{
    Block block;
    Node parent;
    ArrayList<Node> children;
    int level;

    UTXOPool p;

    public Node(Block a, Node b, UTXOPool c)
    {
        block = a;
        parent = b;
        p = c;

        children = new ArrayList<Node>();

        if(parent == null)
        {
            level = 1;
        }

        else
        {
            parent.children.add(this);
            level = parent.level + 1;
        }

    }

}


public class BlockChain 
{
    public static final int CUT_OFF_AGE = 10;
    Node nodemh;
    TransactionPool pool;
    HashMap<ByteArrayWrapper, Node> bc;

    /**
     * create an empty block chain with just a genesis block. Assume {@code genesisBlock} is a valid
     * block
     */
    public BlockChain(Block genesisBlock) 
    {

        pool = new TransactionPool();
        bc = new HashMap();

        UTXOPool up = new UTXOPool();

        Transaction cb = genesisBlock.getCoinbase();

        int i=0;
        while(i<cb.numOutputs()) 
        {
            Transaction.Output out = cb.getOutput(i);
            UTXO u = new UTXO(cb.getHash(), i);
            up.addUTXO(u, out);
            i++;
        }

        Node gn = new Node(genesisBlock, null, up);
        nodemh = gn;
        
        ByteArrayWrapper a = new ByteArrayWrapper(genesisBlock.getHash());
        bc.put(a, gn);
    }

    /** Get the maximum height block */
    public Block getMaxHeightBlock() 
    {
        Block toret = nodemh.block;
        return toret;
    }

    /** Get the UTXOPool for mining a new block on top of max height block */
    public UTXOPool getMaxHeightUTXOPool() 
    {
        UTXOPool ret = nodemh.p;
        return ret;
    }

    /** Get the transaction pool to mine a new block */
    public TransactionPool getTransactionPool() 
    {
        TransactionPool r = pool;
        return r;
    }

    /**
     * Add {@code block} to the block chain if it is valid. For validity, all transactions should be
     * valid and block should be at {@code height > (maxHeight - CUT_OFF_AGE)}.
     * 
     * <p>
     * For example, you can try creating a new block over the genesis block (block height 2) if the
     * block chain height is {@code <=
     * CUT_OFF_AGE + 1}. As soon as {@code height > CUT_OFF_AGE + 1}, you cannot create a new block
     * at height 2.
     * 
     * @return true if block is successfully added
     */
    public boolean addBlock(Block block) 
    {
        byte[] pbh = block.getPrevBlockHash();

        if(pbh!=null)
        {
            ByteArrayWrapper fornow = new ByteArrayWrapper(pbh);
            Node pbn = bc.get(fornow);

            if(pbn!=null)
            {
                TxHandler h = new TxHandler(pbn.p);
                Transaction[] m, n;
                ArrayList<Transaction> temp = block.getTransactions();          
                m = temp.toArray(new Transaction[0]);
                n = h.handleTxs(m);

                if(m.length == n.length)
                {
                    int height = pbn.level + 1;
                    if(height > nodemh.level - CUT_OFF_AGE)
                    {

                        UTXOPool u = h.getUTXOPool();

                        Transaction cb = block.getCoinbase();

                        int i=0;
                        while(i<cb.numOutputs()) 
                        {
                            Transaction.Output out = cb.getOutput(i);
                            UTXO ux = new UTXO(cb.getHash(), i);
                            u.addUTXO(ux, out);
                            i++;
                        }

                        Node node = new Node(block, pbn, u);
                        bc.put(new ByteArrayWrapper(block.getHash()), node);

                        if(height > nodemh.level)
                            nodemh = node;

                        return true;
                    }

                    else
                        return false;
                }

                else
                    return false;

            }

            else
                return false;
        }

        else
            return false;
    }

    /** Add a transaction to the transaction pool */
    public void addTransaction(Transaction tx) 
    {
        pool.addTransaction(tx);
    }
}
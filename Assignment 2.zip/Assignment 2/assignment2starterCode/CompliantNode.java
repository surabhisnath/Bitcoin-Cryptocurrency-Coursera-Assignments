import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import static java.util.stream.Collectors.toSet;

public class CompliantNode implements Node 
{

    boolean[] foll;
    int marked[];
    Set<Transaction> pt;
    double graph;
    double mal;
    double txDist;
    int num_rounds;
    int len;


    public CompliantNode(double p_graph, double p_malicious, double p_txDistribution, int numRounds) 
    {
        graph = p_graph;
        mal = p_malicious;
        txDist = p_txDistribution;
        num_rounds = numRounds;
    }

    public void setFollowees(boolean[] followees) 
    {
        len = followees.length;
        foll = followees;       
        marked = new int[len];
    }

    public void setPendingTransaction(Set<Transaction> pendingTransactions) 
    {
        pt = pendingTransactions;
    }

    public Set<Transaction> sendToFollowers() 
    {
        Set<Transaction> ret = new HashSet<>(pt);
        pt.removeAll(pt);
        return ret;
    }

    public void receiveFromFollowees(Set<Candidate> candidates) 
    {

        Set<Integer> listofsenders = new HashSet<Integer>();

        Iterator<Candidate> it = candidates.iterator();

        for(int k=0; k<candidates.size(); k++)
        {
            if(it.hasNext())
                listofsenders.add(it.next().sender);
        }


        for(int h=0; h<len; h++)
        {
            if(listofsenders.contains(h) == false && foll[h] == true)
            {
                marked[h] = 1;
            }
        }


        Iterator<Candidate> it2 = candidates.iterator();

        for(int y=0; y<candidates.size(); y++)
        {
            if(it2.hasNext())
            {
                Candidate temp = it2.next();
                if(marked[temp.sender] == 0)
                {
                    pt.add(temp.tx);
                }
            }
        }
    }
}